package com.polsl.antiplagiarism.antiplagiarismback.controller;

import java.io.IOException;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.polsl.antiplagiarism.antiplagiarismback.model.domain.demo.Levenshtein;
import com.polsl.antiplagiarism.antiplagiarismback.model.domain.demo.Test;

@RequestMapping(value = "/api/test", produces = MediaType.APPLICATION_JSON_VALUE)
public interface TestControllerApi {
    @GetMapping
    ResponseEntity test();

    @PostMapping("/levenshteinV1")
    ResponseEntity levenshtein(@RequestBody Levenshtein levenshtein) throws IOException;

    @GetMapping("/findV1/{id}")
    ResponseEntity findV1(@PathVariable Integer id);

    @GetMapping("/findV2")
    ResponseEntity findV2(@RequestParam Integer id, @RequestParam String name);

    @PostMapping
    ResponseEntity save(@RequestBody Test test);
}
