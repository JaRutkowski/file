package com.polsl.antiplagiarism.antiplagiarismback.controller.base.impl;

import org.springframework.http.ResponseEntity;

import com.polsl.antiplagiarism.antiplagiarismback.controller.base.FileControllerApi;
import com.polsl.antiplagiarism.antiplagiarismback.service.business.file.FileService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class FileController implements FileControllerApi {
	private final FileService fileService;

	@Override
	public ResponseEntity findByLocalPath(String localPath) {
		return ResponseEntity.ok(fileService.findByLocalPath(localPath));
	}
}
