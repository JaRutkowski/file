package com.polsl.antiplagiarism.antiplagiarismback.controller.impl;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.polsl.antiplagiarism.antiplagiarismback.controller.ReportControllerApi;
import com.polsl.antiplagiarism.antiplagiarismback.service.business.report.ReportService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class ReportController implements ReportControllerApi {
	private final ReportService reportService;

	@Override
	public ResponseEntity findAll() {
		return ResponseEntity.ok(reportService.findAll());
	}
}
