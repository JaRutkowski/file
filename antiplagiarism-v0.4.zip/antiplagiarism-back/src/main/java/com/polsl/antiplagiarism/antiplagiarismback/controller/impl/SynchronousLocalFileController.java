package com.polsl.antiplagiarism.antiplagiarismback.controller.impl;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.polsl.antiplagiarism.antiplagiarismback.controller.SynchronousLocalFileControllerApi;
import com.polsl.antiplagiarism.antiplagiarismback.controller.base.impl.FileController;
import com.polsl.antiplagiarism.antiplagiarismback.controller.dto.ResponseDto;
import com.polsl.antiplagiarism.antiplagiarismback.service.business.file.FileService;
import com.polsl.antiplagiarism.antiplagiarismback.service.business.file.SynchronousLocalFileService;

@RestController
public class SynchronousLocalFileController extends FileController implements SynchronousLocalFileControllerApi {
	private final SynchronousLocalFileService synchronousLocalFileService;

	public SynchronousLocalFileController(FileService fileService, SynchronousLocalFileService synchronousLocalFileService) {
		super(fileService);
		this.synchronousLocalFileService = synchronousLocalFileService;
	}

	@Override
	public ResponseEntity upload(String path) {
		synchronousLocalFileService.upload(path);
		return ResponseEntity.ok(ResponseDto.builder().message(path).build());
	}
}
