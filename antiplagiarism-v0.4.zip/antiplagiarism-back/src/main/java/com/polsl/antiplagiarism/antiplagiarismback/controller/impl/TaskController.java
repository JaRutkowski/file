package com.polsl.antiplagiarism.antiplagiarismback.controller.impl;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.polsl.antiplagiarism.antiplagiarismback.controller.TaskControllerApi;
import com.polsl.antiplagiarism.antiplagiarismback.service.batch.task.TaskService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class TaskController implements TaskControllerApi {
	private final TaskService taskService;

	@Override
	public ResponseEntity scheduleTask(Integer idFileSource) {
		return ResponseEntity.ok(taskService.createTask(idFileSource));
	}
}
