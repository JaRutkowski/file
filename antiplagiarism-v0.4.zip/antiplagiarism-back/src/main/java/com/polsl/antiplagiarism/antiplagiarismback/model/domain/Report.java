package com.polsl.antiplagiarism.antiplagiarismback.model.domain;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "report")
@SequenceGenerator(name = "seq_report", sequenceName = "seq_report", allocationSize = 1)
public class Report {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_report")
    private Integer id;

    @Column(name = "title")
    private String title;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "creation_date")
    private Date creationDate;

    //FIXME: change to FetchType.LAZY
    @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER) //FIXME: Added cascade
    @JoinTable(name = "report_comparison", joinColumns = @JoinColumn(name = "id_comparison"),
            inverseJoinColumns = @JoinColumn(name = "id_report"))
    private List<Comparison> comparisons; //TODO: check why initialization not working = new ArrayList<>();
}
