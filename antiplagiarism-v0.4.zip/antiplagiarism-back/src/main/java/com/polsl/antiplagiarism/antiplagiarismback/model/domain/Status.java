package com.polsl.antiplagiarism.antiplagiarismback.model.domain;

public enum Status {
    TODO, IN_PROGRESS, DONE, FAILED
}
