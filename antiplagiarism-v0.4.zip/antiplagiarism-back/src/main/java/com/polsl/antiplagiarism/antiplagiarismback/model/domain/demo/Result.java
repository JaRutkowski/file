package com.polsl.antiplagiarism.antiplagiarismback.model.domain.demo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Result {
    private int value;
}
