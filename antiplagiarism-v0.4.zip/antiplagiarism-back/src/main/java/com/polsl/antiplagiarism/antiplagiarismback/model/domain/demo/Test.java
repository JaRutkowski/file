package com.polsl.antiplagiarism.antiplagiarismback.model.domain.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "test")
@SequenceGenerator(name = "seq_test", sequenceName = "seq_test", allocationSize = 1)
public class Test {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_test")
    @Column(name = "id_test")
    private Integer idTest;

    private String name;

    private String subName;
}
