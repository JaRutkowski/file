package com.polsl.antiplagiarism.antiplagiarismback.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.polsl.antiplagiarism.antiplagiarismback.model.domain.Comparison;

public interface ComparisonRepository extends JpaRepository<Comparison, Integer> {
}
