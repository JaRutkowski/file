package com.polsl.antiplagiarism.antiplagiarismback.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.polsl.antiplagiarism.antiplagiarismback.model.domain.File;

public interface FileRepository extends JpaRepository<File, Integer> {
	List<File> findAllByIdNotIn(Integer... ids);

	File findByLocalPath(String localPath);
}
