package com.polsl.antiplagiarism.antiplagiarismback.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.polsl.antiplagiarism.antiplagiarismback.model.domain.Status;
import com.polsl.antiplagiarism.antiplagiarismback.model.domain.Task;

public interface TaskRepository extends JpaRepository<Task, Integer> {
	List<Task> findAllByStatusEquals(Status status);
}
