package com.polsl.antiplagiarism.antiplagiarismback.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.polsl.antiplagiarism.antiplagiarismback.model.domain.demo.Test;

public interface TestRepository extends JpaRepository<Test, Integer> {
    List<Test> findAllByIdTestAndNameLike(Integer id, String name);
}
