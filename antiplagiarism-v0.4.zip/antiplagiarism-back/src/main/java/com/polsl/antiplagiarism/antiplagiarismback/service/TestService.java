package com.polsl.antiplagiarism.antiplagiarismback.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.polsl.antiplagiarism.antiplagiarismback.model.domain.demo.Test;
import com.polsl.antiplagiarism.antiplagiarismback.model.repository.TestRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TestService {
    private final TestRepository testRepository;

    public List<Test> findAll() {
        return testRepository.findAll();
    }

    public List<Test> findById(Integer id) {
        return testRepository.findAllById(List.of(id));
    }

    public List<Test> findAllByIdTestAndNameLike(Integer id, String name) {
        return testRepository.findAllByIdTestAndNameLike(id, name);
    }

    public Test save(Test test) {
        return testRepository.save(test);
    }
}
