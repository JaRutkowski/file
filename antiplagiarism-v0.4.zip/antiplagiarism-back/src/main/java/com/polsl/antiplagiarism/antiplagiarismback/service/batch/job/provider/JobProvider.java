package com.polsl.antiplagiarism.antiplagiarismback.service.batch.job.provider;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.polsl.antiplagiarism.antiplagiarismback.model.domain.File;
import com.polsl.antiplagiarism.antiplagiarismback.model.domain.Status;
import com.polsl.antiplagiarism.antiplagiarismback.model.domain.Subtask;
import com.polsl.antiplagiarism.antiplagiarismback.model.domain.Task;
import com.polsl.antiplagiarism.antiplagiarismback.model.repository.FileRepository;
import com.polsl.antiplagiarism.antiplagiarismback.model.repository.SubtaskRepository;
import com.polsl.antiplagiarism.antiplagiarismback.model.repository.TaskRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.java.Log;

@Service
@RequiredArgsConstructor
@Log
public class JobProvider {
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

	private final TaskRepository taskRepository;
	private final FileRepository fileRepository;
	private final SubtaskRepository subtaskRepository;

	/* setup population (subtask) */
	@Scheduled(cron = "${app.schedule.job-provider}")
	public void createPopulation() {
		/* if the new job is identified then the subtask are created */
		log.info("JobProvider.createPopulation() started");
		List<Task> tasks = taskRepository.findAllByStatusEquals(Status.TODO);
		log.info("JobProvider.createPopulation() pending tasks: " + tasks.size());
		tasks.forEach(this::createSubTasks);
		log.info("JobProvider.createPopulation() finished");

	}

	private void createSubTasks(Task task) {
		task.setStatus(Status.IN_PROGRESS);

		//FIXME: check if the query is working
		List<File> files = fileRepository.findAllByIdNotIn(task.getSource());
		files.forEach(file -> {
			subtaskRepository.save(Subtask.builder()
					.creationDate(new Date())
					.source(task.getSource())
					.target(file.getId())
					.task(task)
					.status(Status.TODO)
					.build());
		});

		task.setPopulationSize(files.size());
		task.setPopulationProcessedSuccess(0);
		task.setPopulationProcessedFailed(0);
		taskRepository.save(task);
	}
}
