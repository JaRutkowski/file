package com.polsl.antiplagiarism.antiplagiarismback.service.batch.task;

import java.util.Date;

import org.springframework.stereotype.Service;

import com.polsl.antiplagiarism.antiplagiarismback.model.domain.Status;
import com.polsl.antiplagiarism.antiplagiarismback.model.domain.Task;
import com.polsl.antiplagiarism.antiplagiarismback.model.repository.FileRepository;
import com.polsl.antiplagiarism.antiplagiarismback.model.repository.TaskRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TaskService {
	private final FileRepository fileRepository;
	private final TaskRepository taskRepository;

	public Task createTask(Integer idFileSource) {
		//TODO: Handle exception in the aspects
		fileRepository.findById(idFileSource).orElseThrow(() -> new RuntimeException("File with given id: " + idFileSource + " not exists"));
		return taskRepository.save(Task.builder().creationDate(new Date())
				.status(Status.TODO)
				.source(idFileSource)
				.build());
	}
}
