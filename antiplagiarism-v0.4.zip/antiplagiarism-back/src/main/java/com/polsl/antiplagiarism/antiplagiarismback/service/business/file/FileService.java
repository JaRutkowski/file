package com.polsl.antiplagiarism.antiplagiarismback.service.business.file;

import org.springframework.stereotype.Service;

import com.polsl.antiplagiarism.antiplagiarismback.model.domain.File;
import com.polsl.antiplagiarism.antiplagiarismback.model.repository.FileRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FileService {
	private final FileRepository fileRepository;

	public File findByLocalPath(String localPath) {
		return fileRepository.findByLocalPath(localPath);
	}
}
