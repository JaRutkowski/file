package com.polsl.antiplagiarism.antiplagiarismback.service.business.file;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.polsl.antiplagiarism.antiplagiarismback.model.domain.File;
import com.polsl.antiplagiarism.antiplagiarismback.model.repository.FileRepository;
import com.polsl.antiplagiarism.antiplagiarismback.service.utils.Utils;

import lombok.RequiredArgsConstructor;
import lombok.extern.java.Log;

@Service
@RequiredArgsConstructor
@Log
public class SynchronousLocalFileService {
	@Value("${app.binary.save}")
	private boolean binarySave;

	private final FileRepository fileRepository;

	//TODO: add filter
	public void upload(String path) {
		Path givenPath = Paths.get(path);
		try {
			if (Files.isDirectory(givenPath)) {
				try (Stream<Path> paths = Files.walk(givenPath)) {
					paths.filter(Files::isRegularFile).forEach(file -> {
								try {
									fileRepository.save(buildFile(file));
								} catch (IOException e) {
									log.severe(e.getMessage());
								}
							}
					);
				}
			} else if (Files.isRegularFile(givenPath))
				fileRepository.save(buildFile(givenPath));
		} catch (Exception e) {
			log.severe(e.getMessage());
		}
	}

	private File buildFile(Path path) throws IOException {
		return File.builder().creationDate(new Date())
				.extension(Utils.getFileExtension(path))
				.file(binarySave ? Files.readAllBytes(path) : null)
				.localPath(path.toAbsolutePath().toString())
				.size(path.toFile().length())
				.build();
	}
}
