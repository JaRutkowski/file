package com.polsl.antiplagiarism.antiplagiarismback.service.business.report;

import java.util.List;

import org.springframework.stereotype.Service;

import com.polsl.antiplagiarism.antiplagiarismback.model.domain.Report;
import com.polsl.antiplagiarism.antiplagiarismback.model.repository.ReportRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ReportService {
	private final ReportRepository reportRepository;

	public List<Report> findAll() {
		return reportRepository.findAll();
	}
}
