package com.polsl.antiplagiarism.antiplagiarismback.service.utils;

import java.nio.file.Path;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Utils {
	public String getFileExtension(Path path) {
		String name = path.getFileName().toString();
		int lastIndexOf = name.lastIndexOf(".");
		if (lastIndexOf == -1)
			return "";
		return name.substring(lastIndexOf);
	}
}
