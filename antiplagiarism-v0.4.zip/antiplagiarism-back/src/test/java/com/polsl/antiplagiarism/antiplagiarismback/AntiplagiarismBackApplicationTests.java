package com.polsl.antiplagiarism.antiplagiarismback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AntiplagiarismBackApplicationTests {

    @Test
    void contextLoads() {
    }

}
