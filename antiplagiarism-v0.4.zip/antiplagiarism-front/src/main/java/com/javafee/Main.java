package com.javafee;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import com.javafee.controller.AntiplagiarismController;

import lombok.extern.java.Log;

@Log
public class Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            //TODO: Fabryka obiektów
            AntiplagiarismController.getInstance().control();
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            log.severe(e.getMessage());
        }
    }
}
