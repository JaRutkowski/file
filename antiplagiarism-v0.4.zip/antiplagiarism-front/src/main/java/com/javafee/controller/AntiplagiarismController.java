package com.javafee.controller;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import com.javafee.form.AntiplagiarismForm;
import com.javafee.form.table.ComparisonTableModel;
import com.javafee.form.table.ReportTableModel;
import com.javafee.form.utils.Utils;
import com.javafee.model.api.RestHandler;
import com.javafee.model.api.dto.FileDto;
import com.javafee.model.api.dto.ReportDto;
import com.javafee.model.api.dto.ResponseDto;
import com.javafee.model.api.dto.TaskDto;
import com.mashape.unirest.http.exceptions.UnirestException;

import lombok.extern.java.Log;

@Log
public class AntiplagiarismController {
	private static AntiplagiarismController antiplagiarismController = null;

	private AntiplagiarismForm antiplagiarismForm;
	private RestHandler<ResponseDto> restHandlerResponseDto;
	private RestHandler<TaskDto> restHandlerTaskDto;
	private RestHandler<FileDto> restHandlerFileDto;
	private RestHandler<ReportDto[]> restHandlerReportDto;

	private List<ReportDto> reportDtos;

	private AntiplagiarismController() {
	}

	public static synchronized AntiplagiarismController getInstance() {
		if (antiplagiarismController == null)
			antiplagiarismController = new AntiplagiarismController();
		return antiplagiarismController;
	}

	public void control() {
		this.initialize();

		antiplagiarismForm.getBtnAddFiles().addActionListener(e -> onClickBtnAddFiles());
		antiplagiarismForm.getBtnCheckFile().addActionListener(e -> onClickBtnCheckFile());
		antiplagiarismForm.getBtnRefresh().addActionListener(e -> onClickBtnRefresh());
		antiplagiarismForm.getTableReport().getSelectionModel().addListSelectionListener(e -> {
			if (!e.getValueIsAdjusting())
				onSelectionChangeReportTable();
		});
	}

	private void initialize() {
		antiplagiarismForm = new AntiplagiarismForm();
		antiplagiarismForm.getFrame().setVisible(true);

		restHandlerResponseDto = new RestHandler<>(ResponseDto.class);
		restHandlerTaskDto = new RestHandler<>(TaskDto.class);
		restHandlerFileDto = new RestHandler<>(FileDto.class);
		restHandlerReportDto = new RestHandler<>(ReportDto[].class);

		reloadReportTable();
	}

	public void reloadReportTable() {
		try {
			reportDtos = Arrays.asList(restHandlerReportDto.performGet("report"));
			((ReportTableModel) antiplagiarismForm.getTableReport().getModel()).clear();
			reportDtos.forEach(e -> ((ReportTableModel) antiplagiarismForm.getTableReport().getModel()).add(e));
		} catch (UnirestException e) {
			log.severe(e.getMessage());
		}
	}

	public void reloadComparisonTable(ReportDto report) {
		((ComparisonTableModel) antiplagiarismForm.getTableComparison().getModel()).clear();
		report.getComparisons().forEach(e -> ((ComparisonTableModel) antiplagiarismForm.getTableComparison().getModel()).add(e));
	}

	private void onSelectionChangeReportTable() {
		int selectedIndex = antiplagiarismForm.getTableReport().getSelectedRow();
		if (selectedIndex != -1) {
			int convertedSelectedIndex = antiplagiarismForm.getTableReport().convertRowIndexToModel(selectedIndex);
			reloadComparisonTable(((ReportTableModel) antiplagiarismForm.getTableReport().getModel()).getReport(convertedSelectedIndex));
		}
	}

	private void onClickBtnAddFiles() {
		File file = Utils.displayFileDialog();
		if (file != null) {
			try {
				String path = file.getAbsolutePath().replace('\\', '/');
				restHandlerResponseDto.performPost("file", Map.of("path", path));
				antiplagiarismForm.getTextFieldAddFiles().setText(path);
				Utils.displayDialog(JOptionPane.INFORMATION_MESSAGE, "File(s) from " + path + " uploaded",
						"Information", antiplagiarismForm.getFrame());
			} catch (UnirestException e) {
				log.severe(e.getMessage());
				Utils.displayDialog(JOptionPane.ERROR_MESSAGE, e.getMessage(), "Error", antiplagiarismForm.getFrame());
			}
		}
	}

	private void onClickBtnCheckFile() {
		File file = Utils.displayFileDialog();
		if (file != null) {
			try {
				String path = file.getAbsolutePath();
				TaskDto taskDto = restHandlerTaskDto.performPost("task", Map.of("idFileSource",
						String.valueOf(restHandlerFileDto.performGet("file", Map.of("localPath", path)).getId())));

				antiplagiarismForm.getTextFieldCheckFile().setText(path);
				Utils.displayDialog(JOptionPane.INFORMATION_MESSAGE, "Process started: " + taskDto.toString(),
						"Information", antiplagiarismForm.getFrame());
			} catch (UnirestException e) {
				log.severe(e.getMessage());
				Utils.displayDialog(JOptionPane.ERROR_MESSAGE, e.getMessage(), "Error", antiplagiarismForm.getFrame());
			}
		}
	}

	private void onClickBtnRefresh() {
		reloadReportTable();
	}
}
