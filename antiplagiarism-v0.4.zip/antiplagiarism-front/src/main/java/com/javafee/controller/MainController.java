package com.javafee.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JOptionPane;

import com.javafee.form.MainForm;
import com.javafee.form.utils.Utils;
import com.javafee.model.api.RestHandler;
import com.javafee.model.api.dto.ResultDto;
import com.javafee.model.api.dto.TestDto;
import com.mashape.unirest.http.exceptions.UnirestException;

import lombok.extern.java.Log;

@Log
public class MainController {
    private static MainController mainController = null;

    private RestHandler<TestDto[]> restHandlerTestDtos;
    private RestHandler<TestDto> restHandlerTestDto;
    private RestHandler<ResultDto> restHandlerResultDto;
    private MainForm mainForm;

    private MainController() {
    }

    public static synchronized MainController getInstance() {
        if (mainController == null)
            mainController = new MainController();
        return mainController;
    }

    public void control() {
        this.initialize();

        mainForm.getBtnRestCall().addActionListener(e -> onClickBtnRestCall());
    }

    private void initialize() {
        mainForm = new MainForm();
        mainForm.getFrame().setVisible(true);

        restHandlerTestDtos = new RestHandler<>(TestDto[].class);
        restHandlerTestDto = new RestHandler<>(TestDto.class);
        restHandlerResultDto = new RestHandler<>(ResultDto.class);
    }

    private void onClickBtnRestCall() {
        try {
            if (!mainForm.getCheckBoxExecuteRequestParamsCall().isSelected()
                    && !mainForm.getCheckBoxExecuteRequestWithBodyPOSTCall().isSelected())
                mainForm.getTextAreaResults().setText(Arrays.toString(restHandlerTestDtos.performGet(
                        mainForm.getTextFieldPath().getText()
                )));
            else if (!"".equals(mainForm.getTextAreaSource1().getText()) && !"".equals(mainForm.getTextAreaSource2().getText())) {
                mainForm.getTextAreaResults().setText(restHandlerResultDto.performPost(mainForm.getTextFieldPath().getText(), "application/json",
                        mainForm.getTextAreaBody().getText()).toString());
                return;
            } else if (mainForm.getCheckBoxExecuteRequestParamsCall().isSelected()) {
                String requestParamsString = mainForm.getTextFieldRequestParams().getText();
                String[] requestParamsArr = requestParamsString.split("&");
                Map<String, String> requestParams = new HashMap<>();
                Arrays.stream(requestParamsArr).forEach(e -> {
                    String[] param = e.split("=");
                    requestParams.put(param[0], param[1]);
                });

                mainForm.getTextAreaResults().setText(Arrays.toString(restHandlerTestDtos.performGet(
                        mainForm.getTextFieldPath().getText(), requestParams
                )));
            } else if (mainForm.getCheckBoxExecuteRequestWithBodyPOSTCall().isSelected())
                mainForm.getTextAreaResults().setText(restHandlerTestDto.performPost(mainForm.getTextFieldPath().getText(), "application/json",
                        mainForm.getTextAreaBody().getText()).toString());

        } catch (UnirestException e) {
            log.severe(e.getMessage());
            Utils.displayDialog(JOptionPane.ERROR_MESSAGE, e.getMessage(), "Error", mainForm.getFrame());
        }
    }
}
