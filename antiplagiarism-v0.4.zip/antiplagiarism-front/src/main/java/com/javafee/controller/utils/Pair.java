package com.javafee.controller.utils;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@AllArgsConstructor
@Getter
@Builder
public class Pair<F, S> {
    private F first;
    private S second;
}
