package com.javafee.form;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

import com.javafee.form.table.ComparisonTableModel;
import com.javafee.form.table.ReportTableModel;

import lombok.Getter;
import net.coderazzi.filters.gui.TableFilterHeader;

@Getter
public class AntiplagiarismForm {
	private JPanel panel;
	private JFrame frame;
	private JButton btnAddFiles;
	private JButton btnCheckFile;
	private JTextField textFieldAddFiles;
	private JTextField textFieldCheckFile;
	private JTable tableReport;
	private JTable tableComparison;
	private JButton btnRefresh;

	public AntiplagiarismForm() {
		frame = new JFrame("Antiplagiarism");
		frame.setContentPane(panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
	}

	private void createUIComponents() {
		tableReport = new JTable();
		@SuppressWarnings("unused")
		TableFilterHeader customTableFilterHeaderTableReport = new TableFilterHeader(tableReport);
		tableReport.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tableReport.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		tableReport.setModel(new ReportTableModel());
		tableReport.setAutoCreateRowSorter(true);

		tableComparison = new JTable();
		@SuppressWarnings("unused")
		TableFilterHeader customTableFilterHeaderTableComparison = new TableFilterHeader(tableComparison);
		tableComparison.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tableComparison.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		tableComparison.setModel(new ComparisonTableModel());
		tableComparison.setAutoCreateRowSorter(true);
	}
}
