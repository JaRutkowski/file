package com.javafee.form;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import lombok.Getter;

@Getter
public class MainForm {
    private JFrame frame;
    private JPanel panel;
    private JButton btnRestCall;
    private JTextField textFieldPath;
    private JTextField textFieldRequestParams;
    private JTextArea textAreaResults;
    private JCheckBox checkBoxExecuteRequestParamsCall;
    private JTextArea textAreaBody;
    private JCheckBox checkBoxExecuteRequestWithBodyPOSTCall;
    private JTextArea textAreaSource1;
    private JTextArea textAreaSource2;

    public MainForm() {
        frame = new JFrame("Antiplagiarism");
        frame.setContentPane(panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
    }
}
