package com.javafee.form.table;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.TableModelEvent;
import javax.swing.table.AbstractTableModel;

import com.javafee.form.table.enums.ComparisonTableColumn;
import com.javafee.model.api.dto.ComparisonDto;

public class ComparisonTableModel extends AbstractTableModel {
	private List<ComparisonDto> comparisionDtoList = new ArrayList<>();
	private String[] columns;

	public ComparisonTableModel() {
		super();
		this.columns = new String[]{"Source", "Target", "Levenshtein coefficient", "Matcher coefficient"};
	}

	public void add(ComparisonDto reportDto) {
		comparisionDtoList.add(reportDto);
		this.fireTableDataChanged();
	}

	public void clear(){
		comparisionDtoList.clear();
	}

	@Override
	public int getRowCount() {
		return comparisionDtoList.size();
	}

	@Override
	public int getColumnCount() {
		return columns.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		ComparisonDto result = comparisionDtoList.get(rowIndex);
		switch (ComparisonTableColumn.getByIndex(columnIndex)) {
			case COL_SOURCE:
				return result.getSource().getLocalPath();
			case COL_TARGET:
				return result.getTarget().getLocalPath();
			case COL_LEVENSHTEIN:
				return result.getLevenshteinCoefficient();
			case COL_MATCHER:
				return result.getMatcherCoefficient();
			default:
				return null;
		}
	}

	@Override
	public String getColumnName(int col) {
		return columns[col];
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	@Override
	public void fireTableChanged(TableModelEvent e) {
		super.fireTableChanged(e);
	}
}
