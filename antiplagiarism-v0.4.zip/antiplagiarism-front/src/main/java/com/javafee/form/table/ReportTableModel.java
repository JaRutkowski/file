package com.javafee.form.table;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.TableModelEvent;
import javax.swing.table.AbstractTableModel;

import com.javafee.form.table.enums.ReportTableColumn;
import com.javafee.model.api.dto.ReportDto;

public class ReportTableModel extends AbstractTableModel {
	private List<ReportDto> reportDtoList = new ArrayList<>();
	private String[] columns;

	public ReportTableModel() {
		super();
		this.columns = new String[]{"Title", "Creation date"};
	}

	public void add(ReportDto reportDto) {
		reportDtoList.add(reportDto);
		this.fireTableDataChanged();
	}

	public void clear() {
		reportDtoList.clear();
	}

	public ReportDto getReport(int index) {
		return reportDtoList.get(index);
	}

	@Override
	public int getRowCount() {
		return reportDtoList.size();
	}

	@Override
	public int getColumnCount() {
		return columns.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		ReportDto result = reportDtoList.get(rowIndex);
		switch (ReportTableColumn.getByIndex(columnIndex)) {
			case COL_TITLE:
				return result.getTitle();
			case COL_CREATION_DATE:
				return result.getCreationDate();
			default:
				return null;
		}
	}

	@Override
	public String getColumnName(int col) {
		return columns[col];
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	@Override
	public void fireTableChanged(TableModelEvent e) {
		super.fireTableChanged(e);
	}
}
