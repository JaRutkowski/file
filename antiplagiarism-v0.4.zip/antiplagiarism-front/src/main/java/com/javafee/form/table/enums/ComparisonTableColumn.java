package com.javafee.form.table.enums;

import java.util.Arrays;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ComparisonTableColumn {
	COL_SOURCE(0), COL_TARGET(1), COL_LEVENSHTEIN(2), COL_MATCHER(3);

	private final Integer value;

	public static ComparisonTableColumn getByIndex(Integer index) {
		return Arrays.stream(ComparisonTableColumn.values())
				.filter(item -> item.getValue().equals(index)).findFirst().orElse(null);
	}
}
