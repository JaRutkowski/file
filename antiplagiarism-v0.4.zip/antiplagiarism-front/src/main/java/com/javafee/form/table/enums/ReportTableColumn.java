package com.javafee.form.table.enums;

import java.util.Arrays;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ReportTableColumn {
	COL_TITLE(0), COL_CREATION_DATE(1), COL_SOURCE(2), COL_TARGET(3), COL_LEVENSHTEIN(4), COL_MATCHER(5);

	private final Integer value;

	public static ReportTableColumn getByIndex(Integer index) {
		return Arrays.stream(ReportTableColumn.values())
				.filter(item -> item.getValue().equals(index)).findFirst().orElse(null);
	}
}
