package com.javafee.form.utils;

import java.awt.*;
import java.io.File;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileSystemView;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Utils {
	private String lastChosePath = null;

	public void displayDialog(int type, String message, String title, Component component) {
		JOptionPane optionPane = new JOptionPane();
		optionPane.setMessage("<html>" + message + "</html>");
		optionPane.setMessageType(type);
		JDialog dialog = optionPane.createDialog(component, title);
		dialog.setVisible(true);
	}

	public File displayFileDialog() {
		JFileChooser jfc = new JFileChooser(lastChosePath != null ? lastChosePath : FileSystemView.getFileSystemView().getHomeDirectory().toString());
		jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		File result = null;
		if (jfc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
			result = jfc.getSelectedFile();
			lastChosePath = result.getAbsolutePath();
		}
		return result;
	}
}
