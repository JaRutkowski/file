package com.javafee.model.api;

import java.util.Map;

import com.google.gson.Gson;
import com.javafee.model.utils.SystemProperties;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.mashape.unirest.request.GetRequest;
import com.mashape.unirest.request.HttpRequestWithBody;

public class RestHandler<T> {
	private final String apiPath = SystemProperties.properties.getProperty("app.api");

	private final Gson gson = new Gson();
	private final Class<T> typeParametrizedClass;

	public RestHandler(Class<T> typeParametrizedClass) {
		this.typeParametrizedClass = typeParametrizedClass;
	}

	public T performGet(String path) throws UnirestException {
		return gson.fromJson(Unirest.get(apiPath.concat(path)).asJson().getBody().toString(), typeParametrizedClass);
	}

	public T performGet(String path, String pathParam) throws UnirestException {
		return gson.fromJson(Unirest.get(apiPath.concat(path).concat("/").concat(pathParam))
				.asJson().getBody().toString(), typeParametrizedClass);
	}

	public T performGet(String path, Map<String, String> requestParams) throws UnirestException {
		GetRequest getRequest = Unirest.get(apiPath.concat(path));
		requestParams.forEach((k, v) -> getRequest.queryString(k, resolveByType(v)));
		return gson.fromJson(getRequest.asJson().getBody().toString(), typeParametrizedClass);
	}

	public T performPost(String path, String contentType, String body) throws UnirestException {
		HttpRequestWithBody postRequest = Unirest.post(apiPath.concat(path));
		postRequest.header("Content-Type", contentType);
		postRequest.body(body);
		return gson.fromJson(postRequest.asJson().getBody().toString(), typeParametrizedClass);
	}

	public T performPost(String path, Map<String, String> requestParams) throws UnirestException {
		HttpRequestWithBody postRequest = Unirest.post(apiPath.concat(path));
		requestParams.forEach((k, v) -> postRequest.queryString(k, resolveByType(v)));
		return gson.fromJson(postRequest.asJson().getBody().toString(), typeParametrizedClass);
	}

	public T performPost(String path, String pathParam) throws UnirestException {
		return gson.fromJson(Unirest.post(apiPath.concat(path).concat("/").concat(pathParam))
				.asJson().getBody().toString(), typeParametrizedClass);
	}

	//TODO: Extend with another types
	private Object resolveByType(String s) {
		try {
			return Integer.valueOf(s);
		} catch (Exception e) {
		}
		return s;
	}

	//TODO: [MINOR] put with body and request params + back

	//TODO: RestHandlerTest with JUnit and mocky&SoapUI using profiles

	//TODO: object fabric

	//TODO: native C++

	//TODO: algorithm

}
