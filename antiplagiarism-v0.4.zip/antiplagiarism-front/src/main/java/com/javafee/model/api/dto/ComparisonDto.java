package com.javafee.model.api.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ComparisonDto {
	private FileDto source;
	private FileDto target;
	private String levenshteinCoefficient;
	private String matcherCoefficient;
}
