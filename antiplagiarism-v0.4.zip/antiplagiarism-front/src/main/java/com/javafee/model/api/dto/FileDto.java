package com.javafee.model.api.dto;

import java.util.Date;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FileDto {
	private Integer id;

	private byte[] file;

	private String localPath;

	private String extension;

	private Long size;

	private Date creationDate;
}
