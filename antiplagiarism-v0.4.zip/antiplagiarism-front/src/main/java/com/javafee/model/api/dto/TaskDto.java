package com.javafee.model.api.dto;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
@ToString
public class TaskDto {
	private Integer id;
	private Integer source;
}
