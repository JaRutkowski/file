package com.javafee.model.api.dto;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TestDto implements Serializable {
    private String name;
    private String subName;
}
