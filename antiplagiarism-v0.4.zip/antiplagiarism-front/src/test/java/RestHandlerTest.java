import com.google.gson.Gson;
import com.javafee.model.api.RestHandler;
import com.javafee.model.api.dto.TestDto;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class RestHandlerTest {
    private static RestHandler<TestDto[]> restHandlerTestDtos;
    private static RestHandler<TestDto> restHandlerTestDto;

    @BeforeAll
    static void setup() {
        restHandlerTestDtos = new RestHandler<>(TestDto[].class);
        restHandlerTestDto = new RestHandler<>(TestDto.class);
    }

    @Test
    void givenRestSimpleGetMethod_whenRequestIsExecuted_thenResponseOk() throws UnirestException {
        TestDto[] testDtos = restHandlerTestDtos.performGet("test");
        assertNotNull(testDtos);
    }

    @Test
    void givenRestPathParamGetMethod_whenRequestIsExecuted_thenResponseIsOk() throws UnirestException {
        TestDto[] testDtos = restHandlerTestDtos.performGet("test/findV1", "1");
        assertNotNull(testDtos);
    }

    @Test
    void givenRestRequestParamGetMethod_whenRequestIsExecuted_thenResponseIsOk() throws UnirestException {
        TestDto[] testDtos = restHandlerTestDtos.performGet("test/findV2", Map.of("id", "1", "name", "%Test%"));
        assertNotNull(testDtos);
    }

    @Test
    void givenRestPostMethod_whenRequestIsExecuted_thenResponseIsOk() throws UnirestException {
        TestDto testDto = restHandlerTestDto.performPost("test", "application/json",
                new Gson().toJson(TestDto.builder().name("UnitTest Test").subName("UnitTest Test").build()));
        assertNotNull(testDto);
    }
}
